<?php require_once "vendor/autoload.php"; //PHPMailer Object 
$mail = new PHPMailer\PHPMailer\PHPMailer();
///$mail->isSMTP;

$mail->Host='mail.mazinigroup.com ';
$mail->Port=465;
$mail->SMTPAuth=true;
$mail->SMTPSecure='tls';

$email='dvidura41@gmail.com';

$mail->Username='contact@mazinigroup.com';
$mail->Password='';


$mail->setFrom('contact@mazinigroup.com','MaziniGroup');
$mail->addAddress($email);
$mail->addReplyTo('contact@mazinigroup.com');


$mail->isHTML(true);

$mail->Subject='Php MAiler test 2';
$mail->Body='<h1>fdf fgfdg gfd gfd </h1><br><br><br><h2>gfdg fgfdgfd gfdgfd</h2><br><h3>gfg fgfdgfdg fgfdsg</h3>';

if(!$mail->send()){
    echo" not send mail";
}else{
    echo"msg send in gmail";
}



















?>